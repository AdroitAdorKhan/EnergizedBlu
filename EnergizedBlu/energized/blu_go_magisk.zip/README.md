# Energized Blu 
Lightweight [Energized](https://github.com/AdroitAdorKhan/Energized) Protection.